let strings = {
    "en" : {
        delete_text: "Delete",
        add_text: "Add",
        submit_text: "Submit",
    },
}